package com.yangdai.calc.main.toolbox.functions.algebra;

/**
 * @author 30415
 */
public record Item(String content) {
}
