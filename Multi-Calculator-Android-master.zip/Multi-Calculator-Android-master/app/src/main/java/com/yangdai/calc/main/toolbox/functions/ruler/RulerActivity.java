package com.yangdai.calc.main.toolbox.functions.ruler;

import com.yangdai.calc.R;
import com.yangdai.calc.main.toolbox.functions.BaseFunctionActivity;

public class RulerActivity extends BaseFunctionActivity {

    @Override
    protected void setRootView() {
        setContentView(R.layout.activity_ruler);
    }
}
