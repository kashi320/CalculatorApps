package com.yangdai.calc.main.toolbox.functions.currency;

/**
 * @author 30415
 */
public record Currency(int id, String symbol, String chineseName, String englishName) {
}
