package com.yangdai.calc.main;

import com.yangdai.calc.main.toolbox.ToolBoxItem;

/**
 * @author 30415
 */
public interface ItemClick {
    void onClick(ToolBoxItem item);
}
